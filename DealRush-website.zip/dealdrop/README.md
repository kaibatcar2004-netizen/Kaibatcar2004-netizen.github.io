# DealRush

A mobile-first affiliate-deals website with 10 built-in buying guides.

## Files
- `index.html` — the complete website, including all 10 articles.

## Add affiliate links
Replace each `YOUR_AFFILIATE_LINK` in `index.html` with a real affiliate URL from a programme you have been accepted into. Keep the `rel="nofollow sponsored"` attribute.

## Articles included
1. Best Budget Headphones Under £50
2. Best Gaming Accessories Under £30
3. 10 Useful Tech Buys Under £20
4. Best Home-Workout Equipment for Beginners
5. Best Bluetooth Speakers Under £50
6. Best Phone Accessories Worth Buying
7. Best Gifts for Men Under £30
8. Best Student Essentials on a Budget
9. How to Find Better Budget Tech Deals
10. How to Spot a Genuine Bargain

## Publishing
Upload `index.html` to any static hosting service. Before launch, replace placeholder affiliate links, add your real contact details, and review each affiliate programme's disclosure and promotion rules.
